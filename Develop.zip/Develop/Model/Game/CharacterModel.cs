namespace Model.Game.Characters
{
    public class CharacterModel
    {
        public float Speed;
    }
}
