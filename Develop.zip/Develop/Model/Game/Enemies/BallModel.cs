namespace Model.Game.Characters.Enemies.Ball
{
    public class BallModel
    {

    }
}
