using UnityEngine;
using UnityEngine.UI;

namespace Model.Menu.MenuShop
{
    public class MenuShopModel//TODO ��������� ��������� ������������� � �������������
    {
        public static int Coins { get => PlayerPrefs.GetInt(nameof(Coins), 1000); set => PlayerPrefs.SetInt(nameof(Coins), value); }

        private ShopItem[] ShopItems = new ShopItem[4];

        public GameObject[] ShopItemBuyPanels = new GameObject[4];

        public GameObject[] ShopItemsView = new GameObject[4];

        public Button[] OpenBuyPanelButtons = new Button[4];
        public Button[] CloseBuyPanelButtons = new Button[4];
        public Button[] BuyShopItemButtons = new Button[4];

        public void InitializeShopItems()
        {
            for (int i = 0; i < ShopItems.Length; i++)
            {
                int j = i;

                OpenBuyPanelButtons[j].onClick.AddListener(delegate { OpenBuyPanel(j); });
                CloseBuyPanelButtons[j].onClick.AddListener(delegate { CloseBuyPanel(j); });
                BuyShopItemButtons[j].onClick.AddListener(delegate { TryBuyShopItem(j); });

                ShopItems[j] = new ShopItem(j, ShopItemBuyPanels[j], OpenBuyPanelButtons[j], CloseBuyPanelButtons[j], BuyShopItemButtons[j]);
            }
        }
        private bool TryBuyShopItem(int id)
        {
            if (Coins < 1000) return false;

            Coins -= 1000;

            ShopItems[id].IsOpen++;

            return true;
        }
        private void OpenBuyPanel(int id)
        {
            SetVisibleShopItemViews(false);
            ShopItems[id].BuyPanel.SetActive(true);
        }
        private void CloseBuyPanel(int id)
        {
            ShopItems[id].BuyPanel.SetActive(false);
            SetVisibleShopItemViews(true);
        }
        private void SetVisibleShopItemViews(bool value)
        {
            for (int i = 0; i < ShopItemsView.Length; i++)
            {
                ShopItemsView[i].SetActive(value);
            }
        }
    }
    public class ShopItem
    {
        public int ID;
        public int IsOpen { get => PlayerPrefs.GetInt(nameof(IsOpen) + ID); set => PlayerPrefs.SetInt(nameof(IsOpen) + ID, value); }

        public GameObject BuyPanel;

        public Button OpenBuyPanelButton;
        public Button CloseBuyPanelButton;
        public Button BuyShopItemButton;
        public ShopItem(int id, GameObject buyPanel, Button openBuyPanelButton, Button closeBuyPanelButton, Button buyShopItemButton)
        {
            ID = id;
            BuyPanel = buyPanel;
            OpenBuyPanelButton = openBuyPanelButton;
            CloseBuyPanelButton = closeBuyPanelButton;
            BuyShopItemButton = buyShopItemButton;
        }
    }
}
