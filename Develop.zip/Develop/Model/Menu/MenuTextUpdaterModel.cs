using System.ComponentModel;
using UnityEngine;

namespace Model.Menu.MenuTextUpdater
{
    public class MenuTextUpdaterModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public int Win { get => PlayerPrefs.GetInt(nameof(Win), 0); set { PlayerPrefs.SetInt(nameof(Win), value); PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Win))); } }
        public int Lose { get => PlayerPrefs.GetInt(nameof(Lose), 0); set { PlayerPrefs.SetInt(nameof(Lose), value); PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Lose))); } }
    }
}
