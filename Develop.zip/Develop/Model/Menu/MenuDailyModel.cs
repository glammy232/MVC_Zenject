using Model.Menu.MenuShop;
using System;
using UnityEngine;

namespace Model.Menu.MenuDaily
{
    public class MenuDailyModel//TODO �������� ��������
    {
        public int IsGift { get => PlayerPrefs.GetInt(nameof(IsGift), 0); set => PlayerPrefs.SetInt(nameof(IsGift), value); }
        //public DeterminantCurrentDailyItem DeterminantCurrentDailyItem = new DeterminantCurrentDailyItem();
        public DailyItemTimer DailyItemTimer = new DailyItemTimer();

        public void GetCoins()
        {
            if (IsGift > 0) return;
            MenuShopModel.Coins += 1000;
            IsGift = 1;
        }
    }
    /*public class DeterminantCurrentDailyItem
    {
        private int FirstDay { get => PlayerPrefs.GetInt(nameof(FirstDay), DateTime.Now.Day); set => PlayerPrefs.SetInt(nameof(FirstDay), value); }
        public int CurrentDailyItem()
        {
            var currentDay = 0;

            if (FirstDay >= 28 && CurrentDay() <= 1) currentDay = 1;
            else if (CurrentDay() - FirstDay >= 7) { currentDay = 0; FirstDay = DateTime.Now.Day; }
            else currentDay = CurrentDay() - FirstDay;

            return currentDay;
        }
        private int CurrentDay()
        {
            return DateTime.Now.Day;
        }
    }*/
    public class DailyItemTimer
    {
        public int LastClaimTime { get => PlayerPrefs.GetInt(nameof(LastClaimTime), 24); set => PlayerPrefs.SetInt(nameof(LastClaimTime), value); }
        public string ClaimTime()
        {
            var nextClaimHours = 24 - DateTime.Now.Hour;
            var nextClaimMinutes = 60 - DateTime.Now.Minute;

            return $"{nextClaimHours}:{nextClaimMinutes}";
        }
    }
}
