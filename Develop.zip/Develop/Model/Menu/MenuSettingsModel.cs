using System.ComponentModel;
using UnityEngine;

namespace Model.Menu.MenuSettings
{
    public class MenuSettingsModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public static int Vibration
        {
            get => PlayerPrefs.GetInt(nameof(Vibration), 1);
            set
            {
                PlayerPrefs.SetInt(nameof(Vibration), value);
            }
        }

        public void SetVibration()
        {
            if (Vibration == 0) Vibration = 1;
            else if (Vibration == 1) Vibration = 0;

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Vibration)));
        }
    }
}
