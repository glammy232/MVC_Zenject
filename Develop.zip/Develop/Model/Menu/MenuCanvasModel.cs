using System;
using UnityEngine;
using UnityEngine.UI;

namespace Model.Menu.MenuCanvas
{
    public class MenuCanvasModel
    {
        public event Action<int> ChangedVisibleCanvasGroup;

        public void SetVisibleCanvasGroup(int index)
        {
            ChangedVisibleCanvasGroup?.Invoke(index);
            Debug.Log($"Visible Canvas Group Changed: {index}");
        }
        public void AddListenersOnChangeCanvasGroupButtons(Button[] buttons)
        {
            for (int i = 0; i < buttons.Length; i++)
            {
                int j = i;
                buttons[i].onClick.AddListener(delegate { SetVisibleCanvasGroup(j); });
            }
        }
    }
}
