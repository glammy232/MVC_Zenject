using System.ComponentModel;
using UnityEngine.UI;

namespace Model.Menu.MenuHome
{
    public class MenuHomeModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private int currentLevel;
        public int CurrentLevel
        {
            get => currentLevel;
            set
            {
                currentLevel = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentLevel)));
            }
        }

        public void AddListenersOnButtons(Button[] buttons)
        {
            for (int i = 0; i < buttons.Length; i++)
            {
                int j = i;
                buttons[i].onClick.AddListener(delegate { SetGameLevel(j); });
            }
        }
        public void SetGameLevel(int id) => CurrentLevel = id;
    }
}
