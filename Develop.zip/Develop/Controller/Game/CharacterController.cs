namespace Controller.Game.Characters
{
    public class CharacterController
    {

    }
}
