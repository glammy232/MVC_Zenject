using UnityEngine;

namespace View.Game.Characters
{
    public class CharacterView : MonoBehaviour
    {

    }
}
